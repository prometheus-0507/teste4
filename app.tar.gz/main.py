import flet as ft

def main(page: ft.Page):
    page.title = "Contador"
    txt = ft.Text("0", size=40)

    def inc(e):
        txt.value = str(int(txt.value) + 1)
        page.update()

    page.add(
        txt,
        ft.ElevatedButton("Incrementar", on_click=inc)
    )

ft.app(target=main, view=ft.WEB_BROWSER)
